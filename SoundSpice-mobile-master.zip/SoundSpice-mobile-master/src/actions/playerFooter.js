export const showFooter = () => {
	return { type: 'show_footer' };
};

export const hideFooter = () => {
	return { type: 'hide_footer' };
};
