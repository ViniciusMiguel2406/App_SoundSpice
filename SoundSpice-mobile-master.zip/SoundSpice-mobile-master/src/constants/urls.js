export const repoUrl = 'https://github.com/farshed/SoundSpice-mobile';
