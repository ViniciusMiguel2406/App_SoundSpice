export const dark = {
	foreground: '#1ED760',
	foreground2: 'white',
	background: '#121212',
	elevatedBG: '#1D222D',
	contrast: 'white',
	contrastTrans: 'rgba(255, 255, 255, ',
	fgTrans: 'rgba(30, 215, 96, ',
	bgTrans: 'rgba(18, 18, 18, ',
	current: 'dark'
};
