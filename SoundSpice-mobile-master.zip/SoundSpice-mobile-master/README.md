<p align="center">
  <img src="https://raw.githubusercontent.com/farshed/SoundSpice-mobile/master/docs/logo.png" height=100/>
</p>

SoundSpice is a light-weight and minimalist music player for Android. Focused on aesthetics and simplicity.

<p align="center">
  <a href="https://play.google.com/store/apps/details?id=com.vynilla">Download</a>
<p>

## Powered by

-  React Native
-  Redux
-  Styled Components

## Screenshots

![Screenshot](https://raw.githubusercontent.com/farshed/SoundSpice-mobile/master/docs/screenshots.png)

## Todo

See [TODO](https://github.com/farshed/SoundSpice-mobile/issues/4)
