export const light = {
	foreground: '#2B05EE',
	foreground2: '#2B05EE',
	background: 'white',
	elevatedBG: '#F7F8FB',
	contrast: '#121212',
	contrastTrans: 'rgba(18, 18, 18, ',
	fgTrans: 'rgba(63, 81, 181, ',
	bgTrans: 'rgba(255, 255, 255, ',
	current: 'light'
};
